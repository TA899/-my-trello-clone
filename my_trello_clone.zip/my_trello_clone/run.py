from trello import create_app  # Asegúrate de que este import sea correcto

app = create_app()  # Crea la aplicación utilizando la función create_app

if __name__ == '__main__':
   #app.run(debug=True)  # Ejecuta la aplicación, comentado para produccion 
 pass 